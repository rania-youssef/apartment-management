package Metier;


import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import DAO.Singleton;



public class Afficher implements AbstractAfficher {
	protected static final String Lieux = null;
	private static Connection con=Singleton.getInstance().getConection();
  private static Statement ste;
  public Afficher() {
	  try {
		  ste=con.createStatement();
		  }
	  catch(SQLException ex) {
		  System.out.println(ex);
	  }
  }
	 
	
		 
	public void afficherDuplex() throws SQLException{
	
		 
		ResultSet rs = null; String s;
		s = "select * from duplex"; 
		
		rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 
		 JFrame frame = new JFrame("Duplex"); 
		 
		 frame.setSize(800,600); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel();
		
		 JTable table = new JTable(data,column);
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		 jsp.setBounds(100,100,600,400);
		 JLabel lab=new JLabel("Duplex Disponibles");
		  lab.setBounds(250,20,300,50);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,25));    
	       panel.add(lab);
	       frame.setContentPane(panel);
			 frame.setVisible(true);  }
		
		


	@Override
	public void afficherTriplex() throws SQLException{
		 
		ResultSet rs = null; String s;
		s = "select * from triplex"; 
		
		rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 
		 JFrame frame = new JFrame("Triplex"); 
		 
		 frame.setSize(800,600); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel();
		
		 JTable table = new JTable(data,column);
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		 jsp.setBounds(100,100,600,400);
		 JLabel lab=new JLabel("Triplex Disponibles");
		  lab.setBounds(250,20,300,50);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,25));    
	       panel.add(lab);
	       frame.setContentPane(panel);
			 frame.setVisible(true);  }
		
		
	

	@Override
	public void afficherSouplex()throws SQLException {
		 
		ResultSet rs = null; String s;
		s = "select * from souplex"; 
		
		rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 
		 JFrame frame = new JFrame("Souplex"); 
		 
		 frame.setSize(800,600); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel();
		
		 JTable table = new JTable(data,column);
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		 jsp.setBounds(100,100,600,400);
		 JLabel lab=new JLabel("Souplex Disponibles");
		  lab.setBounds(250,20,300,50);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,25));    
	       panel.add(lab);
	       frame.setContentPane(panel);
			 frame.setVisible(true);  }
		
		
	
	@Override
	public void afficherLogementPrfesionnel()throws SQLException {
		// TODO Auto-generated method stub
		
		 
		ResultSet rs = null; String s;
		s = "select * from LogProf"; 
		
		rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 
		 JFrame frame = new JFrame("Logements Professionnels"); 
		 
		 frame.setSize(800,600); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel();
		
		 JTable table = new JTable(data,column);
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		 jsp.setBounds(100,100,600,400);
		 JLabel lab=new JLabel("Logements Professionel Disponibles");
		  lab.setBounds(250,20,300,50);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,25));    
	       panel.add(lab);
	       frame.setContentPane(panel);
			 frame.setVisible(true);  }
		
	

	@Override
	public void afficherLogementPiece() throws SQLException{
		// TODO Auto-generated method stub
		 
		ResultSet rs = null; String s;
		s = "select * from logPiec"; 
		
		rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 
		 JFrame frame = new JFrame("Logements de 1 � 5 pi�ces"); 
		 
		 frame.setSize(800,600); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel();
		
		 JTable table = new JTable(data,column);
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		 jsp.setBounds(100,100,600,400);
		 JLabel lab=new JLabel("Logements de 1 � 5 pi�ces ");
		  lab.setBounds(250,20,300,50);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,25));    
	       panel.add(lab);
	       frame.setContentPane(panel);
			 frame.setVisible(true);  }
		
		
	}

