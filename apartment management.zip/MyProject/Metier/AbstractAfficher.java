package Metier;

import java.sql.SQLException;

public interface AbstractAfficher {
	public void afficherDuplex() throws SQLException;
	public void afficherTriplex() throws SQLException;
	public void afficherSouplex() throws SQLException;
	public void afficherLogementPrfesionnel()throws SQLException;
	public void afficherLogementPiece() throws SQLException;

}
