package Metier;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;

import DAO.Singleton;
import Interface.Graphic_InterfaceGestionnaire;
import Interface.SeConnecter;

public class Gestion_logements implements Getionnaire{
	

	

	@Override
	public void AjouterDuplex() {
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.AjouterDuplex.getTextID());
		 String add=Interface.AjouterDuplex.getTextADD();
		 int surf=Integer.parseInt(Interface.AjouterDuplex.getTextSURF());
		int Prix=Integer.parseInt(Interface.AjouterDuplex.getTextPRIX());
		try{
			PreparedStatement ps=con.prepareStatement("Insert into Duplex Values('"+id1+"','"+add+"','"+surf+"','"+Prix+"');");
			ps.executeUpdate();
			ps.close();
		}catch(SQLException e) {
			System.out.print(e);
		}
		}
	
	

	@Override
	public void AjouterTriplex() {
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.AjouterTriplex.getTextID());
		 String add=Interface.AjouterTriplex.getTextADD();
		 int surf=Integer.parseInt(Interface.AjouterTriplex.getTextSURF());
		int Prix=Integer.parseInt(Interface.AjouterTriplex.getTextPRIX());
		try{
			PreparedStatement ps=con.prepareStatement("Insert into Triplex Values('"+id1+"','"+add+"','"+surf+"','"+Prix+"');");
			ps.executeUpdate();
			ps.close();
		}catch(SQLException e) {
			System.out.print(e);
		}
		}
	
		
	

	@Override
	public void AjouterSouplex() {
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.AjouterSouplex.getTextID());
		 String add=Interface.AjouterSouplex.getTextADD();
		 Double surf=Double.parseDouble(Interface.AjouterSouplex.getTextSURF());
		double Prix=Double.parseDouble(Interface.AjouterSouplex.getTextPRIX());
		try{
			PreparedStatement ps=con.prepareStatement("Insert into Souplex Values('"+id1+"','"+add+"','"+surf+"','"+Prix+"');");
			ps.executeUpdate();
			ps.close();
		}catch(SQLException e) {
			System.out.print(e);
		}
		}
	
		
	

	@Override
	public void AjouterLogProf() {
		 Connection con=(Connection) Singleton.getInstance().getConection();
		 int id=Integer.parseInt(Interface.AjouterLogProf.getTextID());
		 String add=Interface.AjouterLogProf.getTextADD();
		 int nbb=Integer.parseInt(Interface.AjouterLogProf.getTextNBB());
		 double Surf=Double.parseDouble(Interface.AjouterLogProf.getTextSURF());
		 double Prix=Double.parseDouble(Interface.AjouterLogProf.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("Insert into logprof Values('"+id+"','"+add+"','"+nbb+"','"+Surf+"','"+Prix+"');");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
			}
		 
	

	@Override
	public void AjouterLogPiece() {
		
			 Connection con=(Connection) Singleton.getInstance().getConection();
			 int id=Integer.parseInt(Interface.AjouterLogPiec.getTextID());
			 String add=Interface.AjouterLogPiec.getTextADD();
			 int nbb=Integer.parseInt(Interface.AjouterLogPiec.getTextNBP());
			 double Surf=Double.parseDouble(Interface.AjouterLogPiec.getTextSURF());
			 double Prix=Double.parseDouble(Interface.AjouterLogPiec.getTextPRIX());
			 try{
					PreparedStatement ps=con.prepareStatement("Insert into logpiec Values('"+id+"','"+add+"','"+nbb+"','"+Surf+"','"+Prix+"');");
					ps.executeUpdate();
					ps.close();
				}catch(SQLException e) {
					System.out.print(e);
				}
				}
		
	
	@Override
	public void ModifierDuplex() {
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.ModifierDuplex.getTextID());
		 String add=Interface.ModifierDuplex.getTextADD();
		 int surf=Integer.parseInt(Interface.ModifierDuplex.getTextSURF());
		int Prix=Integer.parseInt(Interface.ModifierDuplex.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("Update duplex set adresse='"+add+"', Surface='"+surf+"', prix='"+Prix+"' where ID='"+id1+"';");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
		
	}

	@Override
	public void ModifierTriplex() {
		// TODO Auto-generated method stub
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.ModifierTriplex.getTextID());
		 String add=Interface.ModifierTriplex.getTextADD();
		 int surf=Integer.parseInt(Interface.ModifierTriplex.getTextSURF());
		int Prix=Integer.parseInt(Interface.ModifierTriplex.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("Update triplex set adresse='"+add+"', Surface='"+surf+"', prix='"+Prix+"' where ID='"+id1+"';");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
		
	}
		
	

	@Override
	public void ModifierSouplex() {
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.ModifierSouplex.getTextID());
		 String add=Interface.ModifierSouplex.getTextADD();
		 int surf=Integer.parseInt(Interface.ModifierSouplex.getTextSURF());
		int Prix=Integer.parseInt(Interface.ModifierSouplex.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("Update souplex set adresse='"+add+"', Surface='"+surf+"', prix='"+Prix+"' where ID='"+id1+"';");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
		
	}
		
	

	@Override
	public void ModifierLogProf() {
		 Connection con=(Connection) Singleton.getInstance().getConection();
		 int id=Integer.parseInt(Interface.ModifierLogProf.getTextID());
		 String add=Interface.ModifierLogProf.getTextADD();
		 int nbb=Integer.parseInt(Interface.ModifierLogProf.getTextNBB());
		 double Surf=Double.parseDouble(Interface.ModifierLogProf.getTextSURF());
		 double Prix=Double.parseDouble(Interface.ModifierLogProf.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("update logprof set adresse='"+add+"',Nombre_bureaux='"+nbb+"',Surface='"+Surf+"',Prix='"+Prix+"' WHERE ID='"+id+"'; ");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
			}
		
	

	@Override
	public void ModifierLogPiece() {
		 Connection con=(Connection) Singleton.getInstance().getConection();
		 int id=Integer.parseInt(Interface.ModifierLogPiec.getTextID());
		 String add=Interface.ModifierLogProf.getTextADD();
		 int nbp=Integer.parseInt(Interface.ModifierLogPiec.getTextNBP());
		 double Surf=Double.parseDouble(Interface.ModifierLogPiec.getTextSURF());
		 double Prix=Double.parseDouble(Interface.ModifierLogPiec.getTextPRIX());
		 try{
				PreparedStatement ps=con.prepareStatement("UPDATE logpiec SET adresse='"+add+"',Nombre_bureaux='"+nbp+"',Surface='"+Surf+"',Prix='"+Prix+"' WHERE ID='"+id+"';");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
		
	}

	@Override
	public void SupprimerDuplex() {
		// TODO Auto-generated method stub
		 java.sql.Connection con=Singleton.getInstance().getConection();
		 int id1=Integer.parseInt(Interface.ModifierDuplex.getTextID());
		 try{
				PreparedStatement ps=con.prepareStatement("delete from duplex WHERE ID='"+id1+"';");
				ps.executeUpdate();
				ps.close();
			}catch(SQLException e) {
				System.out.print(e);
			}
		
	}
	

	@Override
	public void SupprimerTriplex() {
		// TODO Auto-generated method stub
				 java.sql.Connection con=Singleton.getInstance().getConection();
				 int id1=Integer.parseInt(Interface.ModifierTriplex.getTextID());
				 try{
						PreparedStatement ps=con.prepareStatement("delete from triplex WHERE ID='"+id1+"';");
						ps.executeUpdate();
						ps.close();
					}catch(SQLException e) {
						System.out.print(e);
					}
				
			}
		
		
	

	@Override
	public void SupprimerSouplex() {
		
		// TODO Auto-generated method stub
				 java.sql.Connection con=Singleton.getInstance().getConection();
				 int id1=Integer.parseInt(Interface.ModifierSouplex.getTextID());
				 try{
						PreparedStatement ps=con.prepareStatement("delete from souplex WHERE ID='"+id1+"';");
						ps.executeUpdate();
						ps.close();
					}catch(SQLException e) {
						System.out.print(e);
					}
				
			}
		
	

	@Override
	public void SupprimerLogProf() {
		// TODO Auto-generated method stub
				 java.sql.Connection con=Singleton.getInstance().getConection();
				 int id1=Integer.parseInt(Interface.ModifierLogProf.getTextID());
				 try{
						PreparedStatement ps=con.prepareStatement("delete from logprof WHERE ID='"+id1+"';");
						ps.executeUpdate();
						ps.close();
					}catch(SQLException e) {
						System.out.print(e);
					}
				
			}
		
	

	@Override
	public void SupprimerLogPiece() {
		// TODO Auto-generated method stub
				 java.sql.Connection con=Singleton.getInstance().getConection();
				 int id1=Integer.parseInt(Interface.ModifierLogPiec.getTextID());
				 try{
						PreparedStatement ps=con.prepareStatement("delete from logpiec WHERE ID='"+id1+"';");
						ps.executeUpdate();
						ps.close();
					}catch(SQLException e) {
						System.out.print(e);
					}
				
			}	
	

	@Override
	public void Connecter() {
		if(SeConnecter.getTextFieldLogin().equals("")||SeConnecter.getPasswordField().contentEquals("")) {
			 JOptionPane.showMessageDialog(null,"Remplir le(s) champs vide(s)!");
		} else if (SeConnecter.getTextFieldLogin().equals("administrateur")&&SeConnecter.getPasswordField().equals("admin")) {
			Graphic_InterfaceGestionnaire gfg=new Graphic_InterfaceGestionnaire();
			gfg.setVisible(true);
		}else { JOptionPane.showMessageDialog(null,"Password o� UseName invalide !!");
		
	}}}

	
	
