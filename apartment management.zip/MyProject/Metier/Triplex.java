package Metier;

public class Triplex {
	private int ID;
	private String adresse;
	private int Surface;
	private int Prix;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getSurface() {
		return Surface;
	}
	public void setSurface(int surface) {
		Surface = surface;
	}
	public int getPrix() {
		return Prix;
	}
	public void setPrix(int prix) {
		Prix = prix;
	}

}


