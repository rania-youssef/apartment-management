package Metier;

public interface Getionnaire {
	public void Connecter();
	public void AjouterDuplex();
	public void AjouterTriplex();
	public void AjouterSouplex();
	public void AjouterLogProf();
	public void AjouterLogPiece();
	public void ModifierDuplex();
	public void ModifierTriplex();
	public void ModifierSouplex();
	public void ModifierLogProf();
	public void ModifierLogPiece();
	public void SupprimerDuplex();
	public void SupprimerTriplex();
	public void SupprimerSouplex();
	public void SupprimerLogProf();
	public void SupprimerLogPiece();

}

