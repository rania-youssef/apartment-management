package Metier;

public class LogProf {
	private int Id;
	private String adresse;
	private int  Nombre_bureaux;
	private int Surface;
	private int Prix;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getNombre_bureaux() {
		return Nombre_bureaux;
	}
	public void setNombre_bureaux(int nombre_bureaux) {
		Nombre_bureaux = nombre_bureaux;
	}
	public int getSurface() {
		return Surface;
	}
	public void setSurface(int surface) {
		Surface = surface;
	}
	public int getPrix() {
		return Prix;
	}
	public void setPrix(int prix) {
		Prix = prix;
	}
	

}
