package Metier;

public class LogPiec {
private int Id;
private String adresse;
private int Nombre_Pieces;
private int Surface;
private int Prix;
public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public String getAdresse() {
	return adresse;
}
public void setAdresse(String adresse) {
	this.adresse = adresse;
}
public int getNombre_Pieces() {
	return Nombre_Pieces;
}
public void setNombre_Pieces(int nombre_Pieces) {
	Nombre_Pieces = nombre_Pieces;
}
public int getSurface() {
	return Surface;
}
public void setSurface(int surface) {
	Surface = surface;
}
public int getPrix() {
	return Prix;
}
public void setPrix(int prix) {
	Prix = prix;
}

}
