package Interface;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JRadioButtonMenuItem;

public class Graphic_InterfaceGestionnaire extends JFrame {
	private JMenuItem ItemAjouterDuplex;
	private JMenuItem itemAjouterTriplex;
	private JMenuItem ItemAjouterSouplex;
	private JMenuItem ItemModifierDuplex;
	private JMenuItem ItemModifierTriplex;
	private JMenuItem ItemModifierSouplex ;
	private JMenuItem ItemAjouterLogPiec;
	private JMenuItem ItemModifierLogPiec;
	private JMenuItem ItemAjouterLogProf;
	private JMenuItem ItemModifierLogProf;
	
	
	public Graphic_InterfaceGestionnaire() {
		setTitle("Espace  gestionnaire");
		 this.setSize(800, 600);
		    this.setLocationRelativeTo(null);  
		   this.setResizable(false);
		    JPanel pan = new JPanel();
		    this.setContentPane(pan); 
		    pan.setLayout(null);
		    this.setVisible(true);
		    
		    JMenuBar menuBar = new JMenuBar();
		    menuBar.setBounds(0, 0, 794, 26);
		    pan.add(menuBar);
		    
		    JMenu mnBatiments = new JMenu("Batiments");
		    menuBar.add(mnBatiments);
		    
		    JMenu mnNewMenu = new JMenu("Ajouter");
		    mnBatiments.add(mnNewMenu);
		    
		    ItemAjouterDuplex = new JMenuItem("Duplex");
		    mnNewMenu.add(ItemAjouterDuplex);
		    ItemAjouterDuplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		AjouterDuplex mdf=new AjouterDuplex();
			  		try {
						mdf.afficherDuplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		    itemAjouterTriplex = new JMenuItem("Triplex");
		    mnNewMenu.add(itemAjouterTriplex);
		    itemAjouterTriplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		AjouterTriplex mdf=new AjouterTriplex();
			  		try {
						mdf.affichertriplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		    ItemAjouterSouplex = new JMenuItem("Souplex");
		    mnNewMenu.add(ItemAjouterSouplex);
		    ItemAjouterSouplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		AjouterSouplex mdf=new AjouterSouplex();
			  		try {
						mdf.afficherSouplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		    JMenu mnAfficher = new JMenu("Modifier");
		    mnBatiments.add(mnAfficher);
		    
		     ItemModifierDuplex = new JMenuItem("Duplex");
		    mnAfficher.add(ItemModifierDuplex);
		    ItemModifierDuplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		ModifierDuplex mdf=new ModifierDuplex();
			  		try {
						mdf.Afficherduplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		     ItemModifierTriplex = new JMenuItem("Triplex");
		    mnAfficher.add(ItemModifierTriplex);
		    ItemModifierTriplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		ModifierTriplex mdf=new ModifierTriplex();
			  		try {
						mdf.AfficherTriplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		   ItemModifierSouplex = new JMenuItem("Souplex");
		    mnAfficher.add(ItemModifierSouplex);
		    ItemModifierSouplex.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		ModifierSouplex mdf=new ModifierSouplex();
			  		try {
						mdf.AfficherSouplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		    JMenu mnMaison = new JMenu("Logements de 1 \u00E0 5 pi\u00E9ces");
		    menuBar.add(mnMaison);
		    
		   ItemAjouterLogPiec = new JMenuItem("Ajouter");
		    mnMaison.add(ItemAjouterLogPiec);
		    ItemAjouterLogPiec.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		AjouterLogPiec mdf=new AjouterLogPiec();
			  		try {
						mdf.afficherLogPiec();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		    ItemModifierLogPiec = new JMenuItem("Modifier");
		    mnMaison.add(ItemModifierLogPiec);
		   ItemModifierLogPiec.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		ModifierLogPiec mdf=new ModifierLogPiec();
			  		try {
						mdf.afficherLogPiec();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    JMenu mnLogementProfessionel = new JMenu("Logement professionel");
		    menuBar.add(mnLogementProfessionel);
		    
		   ItemAjouterLogProf = new JMenuItem("Ajouter");
		    mnLogementProfessionel.add(ItemAjouterLogProf);
		    ItemAjouterLogProf.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		AjouterLogProf mdf=new AjouterLogProf();
			  		try {
						mdf.afficherLogprof();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});
		    
		   ItemModifierLogProf = new JMenuItem("Modifier");
		    mnLogementProfessionel.add(ItemModifierLogProf);
		    ItemModifierLogProf.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		ModifierLogProf mdf=new ModifierLogProf();
			  		try {
						mdf.afficherLogprof();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			  	}
	});}}
			  	
	
	