package Interface;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Metier.Afficher;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollBar;

public class Graphic_interfaceLogProf extends JFrame {


	 JButton btnLogProfBD;
	 private JTable table;
	 private JTable table_1;
	
	
	public JButton getBtnLogProfBD() {
		return btnLogProfBD;
	}

	public void setBtnLogProfBD(JButton btnLogProfBD) {
		this.btnLogProfBD = btnLogProfBD;
	}

	public Graphic_interfaceLogProf() {
		setTitle("Logement professionnel");

	    this.setSize(973, 600);
	    this.setLocationRelativeTo(null);  
	   this.setResizable(false);
	    this.setVisible(true);
	    JPanel pan = new JPanel();
		 
		   
		   this.setContentPane(pan); 
		    pan.setLayout(null);
		    
		    btnLogProfBD = new JButton("");
		    btnLogProfBD.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		
		    		Afficher aff=new Afficher();
			  		try {
						aff.afficherLogementPrfesionnel();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}}
					
		    });
		    
		    
		    btnLogProfBD.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\logp.png"));
		    btnLogProfBD.setBounds(26, 99, 416, 202);
		    pan.add(btnLogProfBD);
		    
		    JLabel lblNewLabel_1 = new JLabel("Logement Professionnel");
		    lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		    lblNewLabel_1.setBounds(359, 31, 353, 29);
		    pan.add(lblNewLabel_1);
		    
		    JLabel lblNewLabel_2 = new JLabel("+ Atelier :");
		    lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_2.setBounds(26, 351, 94, 47);
		    pan.add(lblNewLabel_2);
		    
		    JLabel lblNewLabel_3 = new JLabel("+ Entrepot :");
		    lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_3.setBounds(26, 398, 110, 16);
		    pan.add(lblNewLabel_3);
		    
		    JLabel lblUsine = new JLabel("+ Usine :");
		    lblUsine.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblUsine.setBounds(26, 456, 94, 16);
		    pan.add(lblUsine);
		    
		    JLabel lblUnLocalOu = new JLabel("un local ou un espace consacr\u00E9 \u00E0 la fabrication.");
		    lblUnLocalOu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		    lblUnLocalOu.setBounds(118, 367, 308, 16);
		    pan.add(lblUnLocalOu);
		    
		    JLabel lblNewLabel_4 = new JLabel(" est un b\u00E2timent logistique destin\u00E9 au ");
		    lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		    lblNewLabel_4.setBounds(128, 400, 298, 16);
		    pan.add(lblNewLabel_4);
		    
		    JLabel lblNewLabel_5 = new JLabel(" stockage et \u00E0 la distribution de biens.");
		    lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		    lblNewLabel_5.setBounds(36, 427, 359, 16);
		    pan.add(lblNewLabel_5);
		    
		    JLabel lblNewLabel_6 = new JLabel(" est un b\u00E2timent ou un ensemble de b\u00E2timents ");
		    lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		    lblNewLabel_6.setBounds(105, 458, 331, 16);
		    pan.add(lblNewLabel_6);
		    
		    JLabel lblNewLabel_6_1 = new JLabel("o\u00F9 sont transform\u00E9es des mati\u00E8res premi\u00E8res  en \u00E9nergie.");
		    lblNewLabel_6_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		    lblNewLabel_6_1.setBounds(26, 485, 400, 16);
		    pan.add(lblNewLabel_6_1);
		   
		  
		    
		
		    
		    JLabel lblNewLabel = new JLabel("");
		    lblNewLabel.setEnabled(false);
		    lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\background1.png"));
		    lblNewLabel.setBounds(0, 0, 967, 565);
		    pan.add(lblNewLabel);
		    
	}
}
