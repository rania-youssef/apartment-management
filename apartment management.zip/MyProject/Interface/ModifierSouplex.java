package Interface;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import DAO.Singleton;
import Metier.Gestion_logements;

public class ModifierSouplex extends JFrame{
	private static JTextField textADD;
	private static JTextField textSURF;
	private static JTextField textPRIX;
private static Connection con=Singleton.getInstance().getConection();
private static Statement ste;
	private static JTextField textID;
	
	
	public static String getTextID() {
		return textID.getText();
	}
	public static String getTextADD() {
		return textADD.getText();
	}
	public static String getTextSURF() {
		return textSURF.getText();
	}
	public static String getTextPRIX() {
		return textPRIX.getText();
	}
	
public ModifierSouplex() {  
	try {
	  ste=con.createStatement();}
catch(SQLException ex) {
	  System.out.println(ex);
}
}
public static void AfficherSouplex () throws SQLException { 
	ResultSet rs = null; String s;

		s = "select * from souplex"; 
		 rs = ste.executeQuery(s);
		 ResultSetMetaData rsmt = rs.getMetaData(); 
		 int c = rsmt.getColumnCount();
		 Vector<String> column = new Vector<String>(c);

		 for(int i = 1; i <= c; i++) {
		 column.add(rsmt.getColumnName(i)); 
		 } 

		 Vector<Vector<String>> data = new Vector<Vector<String>>(); 
		 Vector<String> row = new Vector<String>(); 

		 while(rs.next()) { 
		 row = new Vector<String>(c); 

		 for(int i = 1; i <= c; i++){
		 row.add(rs.getString(i)); 
		 } 

		 data.add(row); 
		 } 

		 JFrame frame = new JFrame("Modifier Souplex"); 
		
		 frame.setSize(900,700); 
		 frame.setLocationRelativeTo(null); 
		 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		 JPanel panel = new JPanel(); 
		
		 JTable table = new JTable(data,column);
		 table.addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent arg) {
					try 
					{
						int i=table.getSelectedRow();
					deplace(i);
					}catch(Exception e) {
						e.printStackTrace();
					}
				}
				private void deplace(int i) {
					textID.setText((String) table.getValueAt(i,0));
					textADD.setText((String) table.getValueAt(i,1));
					textSURF.setText((String) table.getValueAt(i,2));
					textPRIX.setText((String) table.getValueAt(i,3));
					
				}
			});
		 JScrollPane jsp = new JScrollPane(table); 
		 panel.setLayout(null); 
		 panel.add(jsp);
		jsp.setBounds(400,50,450,500);
		  JLabel lab=new JLabel("ID");
		  lab.setBounds(50,50,300,35);
	      lab.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,15));    
	       panel.add(lab);  
	       textID=new JTextField(30);
		   textID.setBounds(50,100,150,25);
		   panel.add(textID);
	       JLabel lab1=new JLabel("Adresse");
			  lab1.setBounds(50,150,100,25);
		      lab1.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,15));    
		       panel.add(lab1);  
		       textADD=new JTextField(30);
			   textADD.setBounds(50,200,150,25);
			   panel.add(textADD);
		       JLabel lab2=new JLabel("Surface");
				  lab2.setBounds(50,250,100,25);
			      lab2.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,15));    
			       panel.add(lab2); 
			       textSURF=new JTextField(30);
				   textSURF.setBounds(50,300,150,25);
				   panel.add(textSURF);
			       JLabel lab3=new JLabel("Prix");
					  lab3.setBounds(50,350,50,25);
				      lab3.setFont(new java.awt.Font(Font.SERIF,Font.BOLD,15));    
				       panel.add(lab3); 
				     textPRIX=new JTextField(30);
					   textPRIX.setBounds(50,400,150,25);
					   panel.add(textPRIX);
						   JButton Modifier=new JButton("Modifier");
						     Modifier.setBounds(250,150,100,30);
						     panel.add(Modifier);
						     Modifier.addActionListener(new ActionListener() {
								  	public void actionPerformed(ActionEvent arg0) {
								  		Gestion_logements gll=new Gestion_logements();
								  		gll.ModifierSouplex();
								  		 JOptionPane.showMessageDialog(null,"Elements Modifi�� avec succ�e!!");
								  	}
						    });			 
						     JButton Supprimer=new JButton("Supprimer");
						     Supprimer.setBounds(250,300,100,30);
						     panel.add(Supprimer);
						     
						     Supprimer.addActionListener(new ActionListener() {
								  	public void actionPerformed(ActionEvent arg0) {
								  		Gestion_logements gll=new Gestion_logements();
								  		gll.SupprimerSouplex();
								  		 JOptionPane.showMessageDialog(null,"Elements Supprim�� avec succ�e!!");
								  	}
						    });									    
									
		 frame.setContentPane(panel);
		 frame.setVisible(true); }
public static void setTextADD(JTextField textADD) {
	ModifierSouplex.textADD = textADD;
}
public static void setTextSURF(JTextField textSURF) {
	ModifierSouplex.textSURF = textSURF;
}
public static void setTextPRIX(JTextField textPRIX) {
	ModifierSouplex.textPRIX = textPRIX;
}
public static void setTextID(JTextField textID) {
	ModifierSouplex.textID = textID;
}
}
