package Interface;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
   public class Graphic_interface extends JFrame {
	   JButton btnUtilisateur;
	   JButton btnGestionnaire;
	   JLabel lbStatue;
	   JLabel lbImage;
	   public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Graphic_interface frame = new Graphic_interface();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
	   public Graphic_interface() {
		
	    this.setTitle("Bienvenue!!");
	    this.setSize(600, 400);
	    this.setLocationRelativeTo(null);  
	    setResizable(false);
	    
	    //Instanciation d'un objet JPanel
	   JPanel pan = new JPanel();
	   pan.setLayout(null);
	   this.setContentPane(pan); 
	     btnUtilisateur = new JButton("Utilisateur");
	     btnUtilisateur.addActionListener(new ActionListener() {
	     	public void actionPerformed(ActionEvent e) {
	     		Graphic_interfaceUser gfu=new Graphic_interfaceUser();
	     		gfu.setVisible(true);     	}
	     });
	     btnUtilisateur.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.BOLD, 14));
	     btnUtilisateur.setBackground(new Color(255, 255, 240));
	    btnUtilisateur.setBounds(193, 289, 208, 41);
	    pan.add(btnUtilisateur);
	    
	    btnGestionnaire = new JButton("Gestionnaire");
	    btnGestionnaire.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		SeConnecter connect= new SeConnecter();
	    		connect.setVisible(true);
	    		
	    	}
	    });
	    btnGestionnaire.setBackground(new Color(255, 255, 255));
	    btnGestionnaire.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.BOLD, 14));
	    btnGestionnaire.setBounds(193, 235, 208, 41);
	    pan.add(btnGestionnaire);
	    
	   lbStatue = new JLabel("Choisir votre statue!");
	   lbStatue.setIcon(null);
	    lbStatue.setFont(new Font("Tahoma", Font.BOLD, 27));
	    lbStatue.setBounds(153, 93, 325, 47);
	    pan.add(lbStatue);
	    
	    lbImage = new JLabel("");
	    lbImage.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\background1.png"));
	    lbImage.setBounds(0, 0, 594, 365);
	    pan.add(lbImage);
	}

	public JButton getBtnUtilisateur() {
		return btnUtilisateur;
	}

	public void setBtnUtilisateur(JButton btnUtilisateur) {
		this.btnUtilisateur = btnUtilisateur;
	}

	public JButton getBtnGestionnaire() {
		return btnGestionnaire;
	}

	public void setBtnGestionnaire(JButton btnGestionnaire) {
		this.btnGestionnaire = btnGestionnaire;
	}

}