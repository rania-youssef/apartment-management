package Interface;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Metier.Afficher;

import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Graphic_interfacePiec extends JFrame {
	 JButton btnPiecBD;
	
	public Graphic_interfacePiec() {
	
	 this.setTitle("Logement de 1 \u00E0 5 pi\u00E9ces");
	 
	    this.setSize(973, 600);
	    this.setLocationRelativeTo(null);  
	   this.setResizable(false);
	    JPanel pan = new JPanel();
		 
		   
		   this.setContentPane(pan); 
		    pan.setLayout(null);
		    
		    btnPiecBD = new JButton("New button");
		    btnPiecBD.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent arg0) {
		    		Afficher aff=new Afficher();
			  		try {
						aff.afficherLogementPiece();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}
		    	
		    });
		    btnPiecBD.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\maison.png"));
		    btnPiecBD.setBounds(12, 90, 434, 217);
		    pan.add(btnPiecBD);
		    
		    JLabel lblNewLabel_1 = new JLabel("1 pi\u00E8ce:");
		    lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_1.setBounds(12, 325, 77, 28);
		    pan.add(lblNewLabel_1);
		    
		    JLabel lblNewLabel_2 = new JLabel("une pi\u00E8ce, un coin cuisine et une salle d\u2019eau.");
		    lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		    lblNewLabel_2.setBounds(96, 332, 331, 16);
		    pan.add(lblNewLabel_2);
		    
		    JLabel lblNewLabel_3 = new JLabel("une chambre, un s\u00E9jour, cuisine et une salle d\u2019eau.");
		    lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel_3.setBounds(96, 373, 458, 16);
		    pan.add(lblNewLabel_3);
		    
		    JLabel lblNewLabel_4 = new JLabel("un s\u00E9jour, 2 chambres, une cuisine et une salle d\u2019eau.");
		    lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel_4.setBounds(96, 408, 458, 26);
		    pan.add(lblNewLabel_4);
		    
		    JLabel lblNewLabel_5 = new JLabel("Logement de 1 \u00E0 5 pi\u00E9ces");
		    lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 25));
		    lblNewLabel_5.setBounds(346, 28, 373, 49);
		    pan.add(lblNewLabel_5);
		    
		    JLabel lblNewLabel_1_1 = new JLabel("2 pi\u00E8ces:");
		    lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_1_1.setBounds(12, 367, 77, 28);
		    pan.add(lblNewLabel_1_1);
		    
		    JLabel lblNewLabel_1_2 = new JLabel("3 pi\u00E8ces:");
		    lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_1_2.setBounds(12, 407, 77, 28);
		    pan.add(lblNewLabel_1_2);
		    
		    JLabel lblNewLabel_1_1_1 = new JLabel("4 pi\u00E8ces:");
		    lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_1_1_1.setBounds(12, 448, 77, 28);
		    pan.add(lblNewLabel_1_1_1);
		    
		    JLabel lblNewLabel_1_1_1_1 = new JLabel("5 pi\u00E8ces:");
		    lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		    lblNewLabel_1_1_1_1.setBounds(12, 489, 77, 28);
		    pan.add(lblNewLabel_1_1_1_1);
		    
		    JLabel lblNewLabel_4_1 = new JLabel("un s\u00E9jour,3 chambres,une cuisine et une salle d\u2019eau.");
		    lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel_4_1.setBounds(96, 449, 458, 26);
		    pan.add(lblNewLabel_4_1);
		    
		    JLabel lblNewLabel_4_2 = new JLabel("un s\u00E9jour, 4 chambres, une cuisine et une salle d\u2019eau.");
		    lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel_4_2.setBounds(96, 490, 458, 26);
		    pan.add(lblNewLabel_4_2);
		    
		    JLabel lblNewLabel = new JLabel("un s\u00E9jour,3 chambres,une cuisine et une salle d\u2019eau");
		    lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\background1.png"));
		    lblNewLabel.setBounds(0, 0, 967, 565);
		    pan.add(lblNewLabel);

}
	public JButton getBtnPiecBD() {
		return btnPiecBD;
	}
	public void setBtnPiecBD(JButton btnPiecBD) {
		this.btnPiecBD = btnPiecBD;
	}	
}
