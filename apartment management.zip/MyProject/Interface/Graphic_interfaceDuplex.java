package Interface;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Metier.Afficher;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Graphic_interfaceDuplex extends JFrame {
	private    JButton btnDuplexBD ;
	private   JButton btnTriplexBD;
	private   JButton btnSouplexBD;
	
	public JButton getBtnDuplexBD() {
		return btnDuplexBD;
	}
	public void setBtnDuplexBD(JButton btnDuplexBD) {
		this.btnDuplexBD = btnDuplexBD;
	}
	public JButton getBtnTriplexBD() {
		return btnTriplexBD;
	}
	public void setBtnTriplexBD(JButton btnTriplexBD) {
		this.btnTriplexBD = btnTriplexBD;
	}
	public JButton getBtnSouplexBD() {
		return btnSouplexBD;
	}
	public void setBtnSouplexBD(JButton btnSouplexBD) {
		this.btnSouplexBD = btnSouplexBD;
	}
	public Graphic_interfaceDuplex() {
		setTitle("Duplex, Triplex, Souplex");
		
		 this.setSize(973, 600);
		    this.setLocationRelativeTo(null);  
		    setResizable(false);
		    JPanel pan = new JPanel();
			   pan.setLayout(null);
			   this.setContentPane(pan); 
			   
			  btnDuplexBD = new JButton("New button");
			  btnDuplexBD.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		Afficher aff=new Afficher();
			  		try {
						aff.afficherDuplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}
			  });
			   btnDuplexBD.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\dup.png"));
			   btnDuplexBD.setBounds(77, 141, 201, 175);
			   pan.add(btnDuplexBD);
			   
			 btnTriplexBD = new JButton("New button");
			 btnTriplexBD.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent arg0) {
			 		Afficher aff=new Afficher();
			  		try {
						aff.afficherTriplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}
			 		
			 	
			 });
			   btnTriplexBD.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\Sans titre-1.png"));
			   btnTriplexBD.setBounds(377, 141, 207, 175);
			   pan.add(btnTriplexBD);
			   
			  btnSouplexBD = new JButton("New button");
			  btnSouplexBD.addActionListener(new ActionListener() {
			  	public void actionPerformed(ActionEvent arg0) {
			  		Afficher aff=new Afficher();
			  		try {
						aff.afficherSouplex();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}}
			  	
			  	
			  });
			   btnSouplexBD.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\sousol.png"));
			   btnSouplexBD.setBounds(695, 141, 207, 175);
			   pan.add(btnSouplexBD);
			   
			   JLabel lblNewLabel_1 = new JLabel("Duplex");
			   lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			   lblNewLabel_1.setBounds(135, 353, 86, 29);
			   pan.add(lblNewLabel_1);
			   
			   JLabel lblNewLabel_2 = new JLabel("Triplex");
			   lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
			   lblNewLabel_2.setBounds(440, 352, 79, 29);
			   pan.add(lblNewLabel_2);
			   
			   JLabel lblNewLabel_3 = new JLabel("Souplex");
			   lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
			   lblNewLabel_3.setBounds(753, 355, 86, 22);
			   pan.add(lblNewLabel_3);
			   
			   JLabel lblNewLabel_4 = new JLabel("Appartement distribu\u00E9 sur deux niveaux");
			   lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
			   lblNewLabel_4.setBounds(57, 395, 257, 37);
			   pan.add(lblNewLabel_4);
			   
			   JLabel lblNewLabel_5 = new JLabel("r\u00E9unis par un escalier int\u00E9rieur.");
			   lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
			   lblNewLabel_5.setBounds(57, 445, 257, 16);
			   pan.add(lblNewLabel_5);
			   
			   JLabel lblNewLabel_4_1 = new JLabel("Appartement distribu\u00E9 sur trois niveaux");
			   lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
			   lblNewLabel_4_1.setBounds(344, 395, 257, 37);
			   pan.add(lblNewLabel_4_1);
			   
			   JLabel lblNewLabel_4_1_1 = new JLabel("r\u00E9unis par un escalier int\u00E9rieur.");
			   lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
			   lblNewLabel_4_1_1.setBounds(344, 435, 257, 37);
			   pan.add(lblNewLabel_4_1_1);
			   
			   JLabel lblNewLabel_4_1_2 = new JLabel("d\u00E9signe un logement situ\u00E9 en partie");
			   lblNewLabel_4_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
			   lblNewLabel_4_1_2.setBounds(680, 395, 257, 37);
			   pan.add(lblNewLabel_4_1_2);
			   
			   JLabel lblNewLabel_4_1_1_1 = new JLabel("au rez-de-chauss\u00E9e et en partie en sous-sol.");
			   lblNewLabel_4_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
			   lblNewLabel_4_1_1_1.setBounds(680, 435, 275, 37);
			   pan.add(lblNewLabel_4_1_1_1);
			   
			   JLabel lblNewLabel_6 = new JLabel("Duplex, triplex et souplex");
			   lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 25));
			   lblNewLabel_6.setBounds(296, 31, 384, 62);
			   pan.add(lblNewLabel_6);
			   
			   JLabel lblNewLabel = new JLabel("");
			   lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
			   lblNewLabel.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\background1.png"));
			   lblNewLabel.setBounds(0, 0, 967, 565);
			   pan.add(lblNewLabel);
	}

}
