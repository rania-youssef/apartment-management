package Interface;

import java.sql.SQLException;

public class tewt {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
Graphic_interface ajd= new Graphic_interface();
  ajd.setVisible(true);

}
}