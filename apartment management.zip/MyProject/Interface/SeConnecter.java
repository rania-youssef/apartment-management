package Interface;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DAO.Singleton;
import Metier.Gestion_logements;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.TextField;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class SeConnecter extends JFrame {
	private static JTextField textFieldLogin;
    private JButton btnLogin;
    private static JPasswordField passwordField;
  
	
	public static String getTextFieldLogin() {
		return textFieldLogin.getText();
	}

	public void setTextFieldLogin(JTextField textFieldLogin) {
		this.textFieldLogin = textFieldLogin;
	}

	

	public JButton getBtnLogin() {
		return btnLogin;
	}

	public void setBtnLogin(JButton btnLogin) {
		this.btnLogin = btnLogin;
	}

	public SeConnecter() {
		setTitle("Se connecter");
		  this.setSize(400, 536);
		    this.setLocationRelativeTo(null);  
		   this.setResizable(false);
		    JPanel pan = new JPanel();
		    this.setContentPane(pan); 
		    pan.setLayout(null);
		    this.setVisible(true);
		    
		    textFieldLogin = new JTextField();
		    textFieldLogin.setBounds(75, 244, 253, 57);
		    pan.add(textFieldLogin);
		    textFieldLogin.setColumns(10);
		   
		    JButton btnLogin = new JButton("Login");
		    btnLogin.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent arg0) {
		    		Gestion_logements gl= new Gestion_logements();
		    		gl.Connecter();
		    	}
		    });
		    
		    btnLogin.setBounds(225, 392, 103, 50);
		    pan.add(btnLogin);
		    
		    passwordField = new JPasswordField();
		    passwordField.setBounds(75, 322, 253, 57);
		    pan.add(passwordField);
		    
		    JLabel lblNewLabel_1 = new JLabel("Login");
		    lblNewLabel_1.setForeground(new Color(255, 255, 255));
		    lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		    lblNewLabel_1.setBounds(76, 208, 72, 23);
		    pan.add(lblNewLabel_1);
		    
		    JLabel lblNewLabel_1_1 = new JLabel("Password");
		    lblNewLabel_1_1.setForeground(Color.WHITE);
		    lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		    lblNewLabel_1_1.setBounds(75, 301, 87, 23);
		    pan.add(lblNewLabel_1_1);
		    
		    JLabel lblNewLabel_1_2 = new JLabel("Se connecter ");
		    lblNewLabel_1_2.setForeground(Color.WHITE);
		    lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		    lblNewLabel_1_2.setBounds(148, 24, 167, 23);
		    pan.add(lblNewLabel_1_2);
		    
		    JLabel lblNewLabel = new JLabel("New label");
		    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\login1.png"));
		    lblNewLabel.setBounds(0, 0, 394, 515);
		    pan.add(lblNewLabel);
		    
	}

	public static String getPasswordField() {
		return passwordField.getText();
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}
}
