package Interface;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Graphic_interfaceUser extends JFrame {
	 JButton btnDuplex;
	 JButton btnPiec;
	 JButton btnLogPro;
	
	public Graphic_interfaceUser() {
		 this.setTitle("Clasement des logements");
		 
		    this.setSize(973, 600);
		    this.setLocationRelativeTo(null);  
		    setResizable(false);
		    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    JPanel pan = new JPanel();
			   pan.setLayout(null);
			   this.setContentPane(pan); 
			   
			   JButton btnDuplexImg = new JButton("New button");
			   btnDuplexImg.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\duplex.png"));
			   btnDuplexImg.setBounds(36, 137, 272, 220);
			   pan.add(btnDuplexImg);
			   
			   JButton btnPiecImg = new JButton("New button");
			   btnPiecImg.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\piec.png"));
			   btnPiecImg.setBounds(345, 137, 272, 220);
			   pan.add(btnPiecImg);
			   
			   JButton btnLogProfImg = new JButton("New button");
			   btnLogProfImg.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\logprof.png"));
			   btnLogProfImg.setBounds(658, 137, 272, 220);
			   pan.add(btnLogProfImg);
			   
			   JLabel lbltitle = new JLabel("Classement des logements");
			   lbltitle.setFont(new Font("Tahoma", Font.BOLD, 24));
			   lbltitle.setBounds(316, 42, 364, 48);
			   pan.add(lbltitle);
			   
			   btnDuplex = new JButton("Duplex, triplex et souplex");
			   btnDuplex.addActionListener(new ActionListener() {
			   	public void actionPerformed(ActionEvent e) {
			   		Graphic_interfaceDuplex gfd=new Graphic_interfaceDuplex();
			   		gfd.setVisible(true);
			   	}
			   });
			   btnDuplex.setFont(new Font("Tahoma", Font.BOLD, 14));
			   btnDuplex.setBounds(60, 415, 212, 48);
			   pan.add(btnDuplex);
			  
			   btnPiec = new JButton("Logement de 1 \u00E0 5 pi\u00E9ces");
			   btnPiec.addActionListener(new ActionListener() {
			   	public void actionPerformed(ActionEvent e) {
			   		Graphic_interfacePiec gfp=new Graphic_interfacePiec();
			   		gfp.setVisible(true);
			   	}
			   });
			   btnPiec.setFont(new Font("Tahoma", Font.BOLD, 14));
			   btnPiec.setBounds(375, 415, 207, 48);
			   pan.add(btnPiec);
			   
			   btnLogPro = new JButton("Logement professionel");
			   btnLogPro.addActionListener(new ActionListener() {
			   	public void actionPerformed(ActionEvent e) {
			   		Graphic_interfaceLogProf gflp=new Graphic_interfaceLogProf();
			   		gflp.setVisible(true);
			   	}
			   });
			   btnLogPro.setFont(new Font("Tahoma", Font.BOLD, 14));
			   btnLogPro.setBounds(696, 415, 200, 48);
			   pan.add(btnLogPro);
			   
			   JLabel lblBackground = new JLabel("");
			   lblBackground.setFont(new Font("Tahoma", Font.BOLD, 14));
			   lblBackground.setIcon(new ImageIcon("C:\\Users\\infomix\\eclipse-workspace\\MyProject\\background1.png"));
			   lblBackground.setBounds(0, 0, 967, 580);
			   pan.add(lblBackground);
		   
	}
	public JButton getBtnDuplex() {
		return btnDuplex;
	}
	public void setBtnDuplex(JButton btnDuplex) {
		this.btnDuplex = btnDuplex;
	}
	public JButton getBtnPiec() {
		return btnPiec;
	}
	public void setBtnPiec(JButton btnPiec) {
		this.btnPiec = btnPiec;
	}
	public JButton getBtnLogPro() {
		return btnLogPro;
	}
	public void setBtnLogPro(JButton btnLogPro) {
		this.btnLogPro = btnLogPro;
	}
}
