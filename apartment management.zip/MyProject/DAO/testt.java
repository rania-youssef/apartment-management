package DAO;

import java.sql.SQLException;

import Interface.Graphic_interface;
import Interface.Graphic_interfaceLogProf;

public class testt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Graphic_interface gf=new Graphic_interface();
	gf.setVisible(true);
	}

}
