package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class Singleton {
	private static Singleton db;
	private Connection con;
	String url="jdbc:mysql://127.0.0.1:3306/myprject";
	String login="root"; 
	String pwd="";
	public Singleton() { try {
		con=DriverManager.getConnection(url,login,pwd);
		
		Statement stmt=con.createStatement(); }
	catch(SQLException ex) {
		System.out.println(ex);
	}
		
		
	} 
	public Connection getConection() {
		// TODO Auto-generated method stub
		return con;
	}
	public static Singleton getInstance()
	{
		if(db==null)
			db=new Singleton();
		return db;
		
	}
	

}